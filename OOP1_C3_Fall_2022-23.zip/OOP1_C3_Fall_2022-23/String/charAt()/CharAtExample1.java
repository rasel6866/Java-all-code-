public class CharAtExample1{  
public static void main(String args[]){  
String name="JAVA";  
char ch=name.charAt(10);//returns the char value at the 10th index  
System.out.println(ch);  
}}  