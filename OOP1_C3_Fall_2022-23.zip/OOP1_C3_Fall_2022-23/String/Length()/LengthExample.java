public class LengthExample{  
public static void main(String args[]){  
String s1="OBJECT ORIENTED PROGRAMMING-1";  
String s2="JAVA";  
System.out.println("string length is: "+s1.length());
//10 is the length of javatpoint string  
System.out.println("string length is: "+s2.length());
//6 is the length of python string  
}}  