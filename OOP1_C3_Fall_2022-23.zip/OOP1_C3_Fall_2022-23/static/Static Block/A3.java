class A3{  
  static{  
  System.out.println("static block is invoked");  
  System.exit(0);  
  }  
} 