public class Exercise1 {
  int x = 5;

  public static void main(String[] args) {
    Exercise1 myObj1 = new Exercise1();  // Object 1
    Exercise1 myObj2 = new Exercise1();  // Object 2
    System.out.println(myObj1.x);
    System.out.println(myObj2.x);
  }
}