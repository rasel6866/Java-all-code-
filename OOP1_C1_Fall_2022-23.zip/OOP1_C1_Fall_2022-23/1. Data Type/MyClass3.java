class MyClass3 { 
    public static void main(String args[]) 
    { 
        boolean b = true; 
        if (b == true) 
            System.out.println("Computer Science"); 
    } 
}