public class MyClass2 {
  public static void main(String[] args) {
    byte myNum = 100;
    System.out.println(myNum);  
  }
}
